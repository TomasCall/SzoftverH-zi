package controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
public class MenuController {
    @FXML
    public TextField whitePlayerName, blackPlayerName;
    @FXML
    public Button helpButton,scoreboardButton,startButton;


    private static final Logger logger = LogManager.getLogger(MenuController.class.getName());

    public MenuController(){
        System.setProperty("log4j.configurationFile","/resources/log4j2.xml");
    }
    public void help(){
        System.out.println("HELP BUTTON PRESSED");
        logger.info("hello");
    }

    public void scoreboard(){
        System.out.println("SCOREBOARD BUTTON PRESSED");
    }

    public void start(){
        System.out.println("START BUTTON PRESSED");
    }
}
