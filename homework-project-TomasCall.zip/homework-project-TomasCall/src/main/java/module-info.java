module game {
    requires javafx.graphics;
    requires javafx.controls;
    requires javafx.fxml;
    requires org.apache.logging.log4j;

    opens game;
    opens controllers;

    exports game;
    exports controllers;
}