# Fehér király vs Fekete király

Adott egy 6 x 8 ,ezőből álló játéktábla amelyre az egyik
játékosnak egy világos, a másiknak egy sötét király sakkfigurát helyeztünk.
A játékosok felváltva következnek lépni. Egy lépésben a figurátvalamelyik
nyolcszomszédos üres mezőre kell elmozdítani majd pedig el kell távolítani
a tábla valamelyik üres mezőjét (értelemszerűen a továbbiakban nem lehet eltávolított mezőre lépni).
Az a játkos nyer aki utoljára tud lépni.
